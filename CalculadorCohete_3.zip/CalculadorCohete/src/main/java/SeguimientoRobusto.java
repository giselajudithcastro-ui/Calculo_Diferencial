/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author gzcru
 */

import org.bytedeco.javacpp.DoublePointer;

import org.bytedeco.opencv.global.opencv_core;
import org.bytedeco.opencv.global.opencv_imgproc;

import org.bytedeco.opencv.opencv_core.Mat;
import org.bytedeco.opencv.opencv_core.Point;
import org.bytedeco.opencv.opencv_core.Rect;
import org.bytedeco.opencv.opencv_tracking.TrackerCSRT;

public class SeguimientoRobusto {

    private TrackerCSRT tracker;
    private final Mat plantilla;
    private Rect cajaActual;

    private int fotogramasSinMovimiento = 0;
    private final double umbral = 0.70;

    public SeguimientoRobusto(
            Mat primerFotograma,
            Rect cajaInicial) {

        cajaActual = copiarCaja(cajaInicial);

        // Guardar una imagen de referencia del cohete.
        plantilla = new Mat(
            primerFotograma,
            cajaActual
        ).clone();

        // Inicializar el rastreador CSRT.
        tracker = TrackerCSRT.create();
        tracker.init(primerFotograma, cajaActual);
    }

    public synchronized Rect actualizar(Mat fotograma) {

        Rect cajaCSRT = copiarCaja(cajaActual);

        boolean encontrado =
                tracker.update(fotograma, cajaCSRT);

        if (encontrado
                && dentroDelFotograma(fotograma, cajaCSRT)) {

            double anteriorX = cajaActual.x()
                    + cajaActual.width() / 2.0;

            double anteriorY = cajaActual.y()
                    + cajaActual.height() / 2.0;

            double nuevoX = cajaCSRT.x()
                    + cajaCSRT.width() / 2.0;

            double nuevoY = cajaCSRT.y()
                    + cajaCSRT.height() / 2.0;

            double dx = nuevoX - anteriorX;
            double dy = nuevoY - anteriorY;

            double movimiento = Math.sqrt(
                dx * dx + dy * dy
            );

            if (movimiento <= 2.0) {
                fotogramasSinMovimiento++;
            } else {
                fotogramasSinMovimiento = 0;
            }

            if (fotogramasSinMovimiento < 5) {
                cajaActual = copiarCaja(cajaCSRT);
                return copiarCaja(cajaActual);
            }

            System.out.println(
                "Posible pérdida: buscando el cohete..."
            );

        } else {
            fotogramasSinMovimiento = 5;
        }

        // Buscar primero cerca de la última ubicación.
        Rect recuperado =
                buscarPlantilla(fotograma, true);

        // Si no se encuentra, buscar en todo el fotograma.
        if (recuperado == null) {
            recuperado =
                    buscarPlantilla(fotograma, false);
        }

        if (recuperado == null) {
            return null;
        }

        // Reiniciar el rastreador en la ubicación recuperada.
        cajaActual = copiarCaja(recuperado);
        tracker.close();

        tracker = TrackerCSRT.create();
        tracker.init(fotograma, cajaActual);

        fotogramasSinMovimiento = 0;

        System.out.println("¡Cohete recuperado!");

        return copiarCaja(cajaActual);
    }

    private Rect buscarPlantilla(
            Mat fotograma,
            boolean busquedaLocal) {

        if (plantilla.empty()) {
            return null;
        }

        int ancho = fotograma.cols();
        int alto = fotograma.rows();

        int x = 0;
        int y = 0;
        int anchoBusqueda = ancho;
        int altoBusqueda = alto;

        if (busquedaLocal) {

            int margenX = Math.max(
                cajaActual.width() * 3,
                plantilla.cols() * 2
            );

            int margenY = Math.max(
                cajaActual.height() * 3,
                plantilla.rows() * 2
            );

            x = Math.max(
                0,
                cajaActual.x() - margenX
            );

            y = Math.max(
                0,
                cajaActual.y() - margenY
            );

            int derecha = Math.min(
                ancho,
                cajaActual.x()
                    + cajaActual.width()
                    + margenX
            );

            int abajo = Math.min(
                alto,
                cajaActual.y()
                    + cajaActual.height()
                    + margenY
            );

            anchoBusqueda = derecha - x;
            altoBusqueda = abajo - y;
        }

        if (anchoBusqueda < plantilla.cols()
                || altoBusqueda < plantilla.rows()) {
            return null;
        }

        Rect region = new Rect(
            x,
            y,
            anchoBusqueda,
            altoBusqueda
        );

        Mat zona = new Mat(fotograma, region);
        Mat resultado = new Mat();

        DoublePointer minimo = new DoublePointer(1);
        DoublePointer maximo = new DoublePointer(1);

        Point ubicacionMinima = new Point();
        Point ubicacionMaxima = new Point();

        try {

            opencv_imgproc.matchTemplate(
                zona,
                plantilla,
                resultado,
                opencv_imgproc.TM_CCOEFF_NORMED
            );

            opencv_core.minMaxLoc(
                resultado,
                minimo,
                maximo,
                ubicacionMinima,
                ubicacionMaxima,
                null
            );

            double similitud = maximo.get(0);

            if (similitud < umbral) {
                return null;
            }

            int nuevoX =
                    x + ubicacionMaxima.x();

            int nuevoY =
                    y + ubicacionMaxima.y();

            return new Rect(
                nuevoX,
                nuevoY,
                plantilla.cols(),
                plantilla.rows()
            );

        } finally {
            zona.release();
            resultado.release();
            minimo.close();
            maximo.close();
        }
    }

    private boolean dentroDelFotograma(
            Mat fotograma,
            Rect caja) {

        return caja.x() >= 0
                && caja.y() >= 0
                && caja.width() > 0
                && caja.height() > 0
                && caja.x() + caja.width()
                    <= fotograma.cols()
                && caja.y() + caja.height()
                    <= fotograma.rows();
    }

    private Rect copiarCaja(Rect caja) {

        return new Rect(
            caja.x(),
            caja.y(),
            caja.width(),
            caja.height()
        );
    }

    public synchronized void liberar() {
        plantilla.release();
        tracker.close();
    }
}
