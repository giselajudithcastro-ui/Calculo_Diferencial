 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author gzcru
 */

import org.bytedeco.opencv.global.opencv_highgui;
import org.bytedeco.opencv.global.opencv_imgproc;
import org.bytedeco.opencv.opencv_core.Mat;
import org.bytedeco.opencv.opencv_core.Point;
import org.bytedeco.opencv.opencv_core.Rect;
import org.bytedeco.opencv.opencv_core.Scalar;
import org.bytedeco.opencv.opencv_videoio.VideoCapture;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CalculadorCohete {

    private static class Registro {
        final int fotograma;
        final double tiempo;
        final double x;
        final double y;
        final double altura;

        Registro(int fotograma, double tiempo,
                 double x, double y, double altura) {
            this.fotograma = fotograma;
            this.tiempo = tiempo;
            this.x = x;
            this.y = y;
            this.altura = altura;
        }
    }

    public static void main(String[] args) {

        try (Scanner scanner = new Scanner(System.in)) {

            System.out.println("==============================================");
            System.out.println(" CALCULADORA DE ALTURA DE HIDROCOHETE");
            System.out.println("==============================================");

            System.out.print("Ingresa la ruta del video: ");

            String videoPath = scanner.nextLine()
                    .trim()
                    .replace("\"", "")
                    .replace("'", "");

            File videoFile = new File(videoPath);

            if (!videoFile.isFile()) {
                System.out.println("No se encontró el video.");
                return;
            }

            VideoCapture cap = new VideoCapture(videoPath);

            if (!cap.isOpened()) {
                System.out.println("No se pudo abrir el video.");
                cap.release();
                return;
            }

            double fps = cap.get(5);

            if (!Double.isFinite(fps) || fps < 1 || fps > 240) {
                fps = 30.0;
                System.out.println(
                    "Aviso: se utilizarán 30 FPS como estimación."
                );
            }

            System.out.printf("FPS: %.2f%n", fps);

            Mat primerFotograma = new Mat();

            if (!cap.read(primerFotograma)
                    || primerFotograma.empty()) {
                System.out.println(
                    "No se pudo leer el primer fotograma."
                );
                primerFotograma.release();
                cap.release();
                return;
            }

            System.out.println(
                "\nPASO 1: selecciona el objeto de referencia."
            );

            System.out.println(
                "Debe tener una longitud conocida y estar, " +
                "preferentemente, en el mismo plano del cohete."
            );

            Rect referencia = opencv_highgui.selectROI(
                "Selecciona la referencia",
                primerFotograma,
                false,
                false
            );

            opencv_highgui.destroyWindow(
                "Selecciona la referencia"
            );

            if (referencia.width() <= 0
                    || referencia.height() <= 0) {
                System.out.println(
                    "Referencia no válida."
                );
                primerFotograma.release();
                cap.release();
                return;
            }

            double longitudReal = pedirLongitud(scanner);

            // Escala vertical aproximada en metros por píxel.
            double metrosPorPixel =
                    longitudReal / referencia.height();

            System.out.printf(
                "Escala: %.6f metros/píxel%n",
                metrosPorPixel
            );

            System.out.println(
                "\nPASO 2: selecciona el cohete."
            );

            Rect cajaCohete = opencv_highgui.selectROI(
                "Selecciona el cohete",
                primerFotograma,
                false,
                false
            );

            opencv_highgui.destroyWindow(
                "Selecciona el cohete"
            );

            if (cajaCohete.width() <= 0
                    || cajaCohete.height() <= 0) {
                System.out.println(
                    "No se seleccionó el cohete."
                );
                primerFotograma.release();
                cap.release();
                return;
            }

            SeguimientoRobusto seguimiento =
                    new SeguimientoRobusto(
                        primerFotograma,
                        cajaCohete
                    );

            double yInicial = cajaCohete.y()
                    + cajaCohete.height() / 2.0;

            double xInicial = cajaCohete.x()
                    + cajaCohete.width() / 2.0;

            List<Registro> datos = new ArrayList<>();

            datos.add(new Registro(
                0, 0, xInicial, yInicial, 0
            ));

            List<Point> trayectoria = new ArrayList<>();

            trayectoria.add(new Point(
                (int) Math.round(xInicial),
                (int) Math.round(yInicial)
            ));

            int numeroFotograma = 0;
            Mat frame = new Mat();

            System.out.println(
                "\nSeguimiento iniciado. Presiona q para terminar."
            );

            try {
                while (cap.read(frame) && !frame.empty()) {

                    numeroFotograma++;

                    // =========================================================================
                    // 1. APLICAR FILTRO DE FONDO: Eliminamos verde, azul y blanco del frame
                    // =========================================================================
                    Mat frameLimpio = FiltroFondoNodeseado.eliminarColoresFondo(frame);

                    // 2. ACTUALIZAR SEGUIMIENTO: Usamos el frame limpio para que el tracker no falle
                    Rect caja = seguimiento.actualizar(frameLimpio);

                    // 3. LIBERAR MEMORIA: Limpiamos el Mat temporal de esta iteración
                    frameLimpio.release();
                    // =========================================================================

                    if (caja != null) {

                        double x = caja.x()
                                + caja.width() / 2.0;

                        double y = caja.y()
                                + caja.height() / 2.0;

                        double tiempo = numeroFotograma / fps;

                        // Positivo cuando el cohete sube.
                        double altura = (yInicial - y)
                                * metrosPorPixel;

                        datos.add(new Registro(
                            numeroFotograma,
                            tiempo,
                            x,
                            y,
                            altura
                        ));

                        trayectoria.add(new Point(
                            (int) Math.round(x),
                            (int) Math.round(y)
                        ));

                        opencv_imgproc.rectangle(
                            frame,
                            caja,
                            new Scalar(0, 255, 0, 0),
                            2,
                            opencv_imgproc.LINE_8,
                            0
                        );

                        opencv_imgproc.putText(
                            frame,
                            String.format(
                                "Altura estimada: %.2f m",
                                altura
                            ),
                            new Point(20, 35),
                            opencv_imgproc.FONT_HERSHEY_SIMPLEX,
                            0.75,
                            new Scalar(0, 255, 0, 0),
                            2,
                            opencv_imgproc.LINE_AA,
                            false
                        );

                        opencv_imgproc.putText(
                            frame,
                            String.format(
                                "Tiempo: %.2f s",
                                tiempo
                            ),
                            new Point(20, 65),
                            opencv_imgproc.FONT_HERSHEY_SIMPLEX,
                            0.65,
                            new Scalar(0, 255, 0, 0),
                            2,
                            opencv_imgproc.LINE_AA,
                            false
                        );

                    } else {

                        opencv_imgproc.putText(
                            frame,
                            "Buscando cohete...",
                            new Point(20, 35),
                            opencv_imgproc.FONT_HERSHEY_SIMPLEX,
                            0.75,
                            new Scalar(0, 0, 255, 0),
                            2,
                            opencv_imgproc.LINE_AA,
                            false
                        );
                    }
                    opencv_highgui.imshow(
                        "Seguimiento y trayectoria del cohete",
                        frame
                    );

                    int tecla =
                            opencv_highgui.waitKey(1) & 0xFF;

                    if (tecla == 'q' || tecla == 27) {
                        break;
                    }
                }

            } finally {
                frame.release();
                cap.release();
                seguimiento.liberar();
                primerFotograma.release();
                opencv_highgui.destroyAllWindows();
            }

            if (datos.size() < 2) {
                System.out.println(
                    "No hay suficientes detecciones."
                );
                return;
            }

            Registro maximo = datos.get(0);

            for (Registro r : datos) {
                if (r.altura > maximo.altura) {
                    maximo = r;
                }
            }

            double alturaMaxima =
                    Math.max(0, maximo.altura);

            double duracion =
                    datos.get(datos.size() - 1).tiempo;

            File carpeta = videoFile
                    .getAbsoluteFile()
                    .getParentFile();

            File csv = new File(
                carpeta,
                "trayectoria_cohete.csv"
            );

            guardarCSV(csv, datos);

            System.out.println(
                "\n========== RESULTADOS =========="
            );

            System.out.printf(
                "Altura máxima estimada: %.2f m%n",
                alturaMaxima
            );

            System.out.printf(
                "Tiempo del punto más alto: %.2f s%n",
                maximo.tiempo
            );

            System.out.printf(
                "Duración procesada: %.2f s%n",
                duracion
            );

            System.out.printf(
                "Fotogramas registrados: %d%n",
                datos.size()
            );

            System.out.println(
                "Archivo CSV: " + csv.getAbsolutePath()
            );

            System.out.println(
                "Nota: la altura es una estimación basada " +
                "en la escala y la perspectiva del video."
            );
        }
    }

    private static double pedirLongitud(Scanner scanner) {

        while (true) {

            System.out.print(
                "Longitud real de la referencia en metros: "
            );

            try {
                double valor = Double.parseDouble(
                    scanner.nextLine()
                            .trim()
                            .replace(',', '.')
                );

                if (Double.isFinite(valor) && valor > 0) {
                    return valor;
                }

            } catch (NumberFormatException ignored) {
                // Solicitar nuevamente el valor.
            }

            System.out.println(
                "Introduce un número mayor que cero."
            );
        }
    }

    private static void guardarCSV(
            File archivo,
            List<Registro> datos) {

        try (BufferedWriter writer =
                     new BufferedWriter(
                         new FileWriter(archivo)
                     )) {

            writer.write(
                "fotograma,tiempo_s,x_px,y_px,altura_estimada_m"
            );

            writer.newLine();

            for (Registro r : datos) {

                writer.write(String.format(
                    java.util.Locale.US,
                    "%d,%.5f,%.3f,%.3f,%.5f",
                    r.fotograma,
                    r.tiempo,
                    r.x,
                    r.y,
                    r.altura
                ));

                writer.newLine();
            }

            System.out.println(
                "CSV guardado correctamente."
            );

        } catch (IOException e) {

            System.out.println(
                "Error al guardar el CSV: " + e.getMessage()
            );
        }
    }
}