/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author gzcru
 */
import org.bytedeco.opencv.global.opencv_core;
import org.bytedeco.opencv.global.opencv_imgproc;
import org.bytedeco.opencv.opencv_core.Mat;
import org.bytedeco.opencv.opencv_core.Scalar;

public class FiltroFondoNodeseado {

    // Definimos los rangos como Mat (requerido por la firma de inRange en JavaCV)
    private static final Mat VERDE_MIN = new Mat(1, 1, opencv_core.CV_8UC3, new Scalar(35, 40, 40, 0));
    private static final Mat VERDE_MAX = new Mat(1, 1, opencv_core.CV_8UC3, new Scalar(85, 255, 255, 0));

    private static final Mat AZUL_MIN = new Mat(1, 1, opencv_core.CV_8UC3, new Scalar(100, 50, 50, 0));
    private static final Mat AZUL_MAX = new Mat(1, 1, opencv_core.CV_8UC3, new Scalar(140, 255, 255, 0));

    private static final Mat BLANCO_MIN = new Mat(1, 1, opencv_core.CV_8UC3, new Scalar(0, 0, 200, 0));
    private static final Mat BLANCO_MAX = new Mat(1, 1, opencv_core.CV_8UC3, new Scalar(180, 30, 255, 0));

    /**
     * Recibe un fotograma en formato BGR (JavaCV) y devuelve un fotograma limpio
     * donde los colores verde, azul y blanco del fondo se eliminan (quedan en negro).
     */
    public static Mat eliminarColoresFondo(Mat frameBgr) {
        Mat frameHsv = new Mat();
        opencv_imgproc.cvtColor(frameBgr, frameHsv, opencv_imgproc.COLOR_BGR2HSV);

        // 1. Aplicar inRange usando los Mat definidos arriba
        Mat mascaraVerde = new Mat();
        opencv_core.inRange(frameHsv, VERDE_MIN, VERDE_MAX, mascaraVerde);

        Mat mascaraAzul = new Mat();
        opencv_core.inRange(frameHsv, AZUL_MIN, AZUL_MAX, mascaraAzul);

        Mat mascaraBlanco = new Mat();
        opencv_core.inRange(frameHsv, BLANCO_MIN, BLANCO_MAX, mascaraBlanco);

        // 2. Combinar todas las máscaras de colores no deseados en una sola
        Mat fondoNoDeseado = new Mat();
        opencv_core.bitwise_or(mascaraVerde, mascaraAzul, fondoNoDeseado);
        opencv_core.bitwise_or(fondoNoDeseado, mascaraBlanco, fondoNoDeseado);

        // 3. Invertir la máscara: Lo que era fondo pasa a negro (0) y lo demás a blanco (255)
        Mat mascaraValida = new Mat();
        opencv_core.bitwise_not(fondoNoDeseado, mascaraValida);

        // 4. Aplicar la máscara limpia al frame original
        Mat frameFiltrado = new Mat();
        opencv_core.bitwise_and(frameBgr, frameBgr, frameFiltrado, mascaraValida);

        // Liberar memoria temporal de las máscaras de este fotograma
        frameHsv.release();
        mascaraVerde.release();
        mascaraAzul.release();
        mascaraBlanco.release();
        fondoNoDeseado.release();
        mascaraValida.release();

        return frameFiltrado; // Este es el frame limpio listo para el tracker
    }
}