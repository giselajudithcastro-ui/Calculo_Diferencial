 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author gzcru
 */
import org.bytedeco.opencv.global.opencv_highgui;
import org.bytedeco.opencv.global.opencv_imgproc;
import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.opencv_tracking.TrackerCSRT;
import org.bytedeco.opencv.opencv_videoio.VideoCapture;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class CalculadorCohete {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("==================================================");
        System.out.println("   CALCULADORA DE ALTURA MÁXIMA DE HIDROCOHETE   ");
        System.out.println("==================================================");

        // 1. Pedir ruta del video
        String videoPath = "";
        while (true) {
            System.out.print("\nIngresa la ruta o nombre del archivo de video (ej. C:\\cohete.mp4): ");
            videoPath = scanner.nextLine().trim().replace("\"", "").replace("'", "");
            File file = new File(videoPath);
            if (file.exists()) {
                break;
            }
            System.out.println(" El archivo no existe o la ruta es incorrecta. Inténtalo de nuevo.");
        }

        VideoCapture cap = new VideoCapture(videoPath);
        if (!cap.isOpened()) {
            System.out.println(" No se pudo abrir el archivo de video.");
            return;
        }

        Mat frameInicial = new Mat();
        if (!cap.read(frameInicial) || frameInicial.empty()) {
            System.out.println(" No se pudo leer el primer fotograma del video.");
            cap.release();
            return;
        }

        // 2. Calibración de escala
        System.out.println("\n--- PASO 1: CALIBRACIÓN ---");
        System.out.println("1. Selecciona con el ratón el objeto de referencia (ej. la botella).");
        System.out.println("2. Presiona ENTER o ESPACIO para confirmar la selección.");

        Rect bboxReferencia = opencv_highgui.selectROI("Calibracion: Objeto de referencia", frameInicial, true, false);
        opencv_highgui.destroyWindow("Calibracion: Objeto de referencia");

        if (bboxReferencia.width() == 0 || bboxReferencia.height() == 0) {
            System.out.println(" No se seleccionó ningún objeto de referencia.");
            cap.release();
            return;
        }

        double longitudRealMetros = 0;
        while (true) {
            try {
                System.out.print("\nIngresa la longitud real del objeto en metros (ej. 0.30 para 30 cm): ");
                longitudRealMetros = Double.parseDouble(scanner.nextLine().trim());
                if (longitudRealMetros > 0) break;
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Ingresa un número válido.");
            }
        }

        double metrosPorPixel = longitudRealMetros / bboxReferencia.height();
        System.out.printf("-> Escala calculada: 1 píxel = %.6f metros\n", metrosPorPixel);

        // 3. Selección del cohete
        System.out.println("\n--- PASO 2: SELECCIÓN DEL COHETE ---");
        System.out.println("1. Dibuja un cuadro alrededor del cohete en su posición inicial.");
        System.out.println("2. Presiona ENTER o ESPACIO para iniciar el seguimiento.");

        Rect bboxCohete = opencv_highgui.selectROI("Seleccion: Marca el cohete", frameInicial, true, false);
        opencv_highgui.destroyWindow("Seleccion: Marca el cohete");

        if (bboxCohete.width() == 0 || bboxCohete.height() == 0) {
            System.out.println(" No se seleccionó el cohete.");
            cap.release();
            return;
        }

        // Inicializar Tracker
        TrackerCSRT tracker = TrackerCSRT.create();
        tracker.init(frameInicial, bboxCohete);

        double yInicialPx = bboxCohete.y() + (bboxCohete.height() / 2.0);
        List<Double> posicionesY = new ArrayList<>();
        posicionesY.add(yInicialPx);

        System.out.println("\nProcesando video... Presiona 'q' en la ventana para detener.");

        Mat frame = new Mat();
        while (cap.read(frame)) {
            if (frame.empty()) break;

            boolean ok = tracker.update(frame, bboxCohete);

            if (ok) {
                double centroY = bboxCohete.y() + (bboxCohete.height() / 2.0);
                posicionesY.add(centroY);

                opencv_imgproc.rectangle(frame, bboxCohete, new Scalar(0, 255, 0, 255), 2, opencv_imgproc.LINE_8, 0);
                opencv_imgproc.putText(frame, "Rastreando cohete", 
                        new Point(bboxCohete.x(), bboxCohete.y() - 10), 
                        opencv_imgproc.FONT_HERSHEY_SIMPLEX, 0.5, new Scalar(0, 255, 0, 255), 2, 0, false);
            } else {
                opencv_imgproc.putText(frame, "Seguimiento perdido", 
                        new Point(100, 80), 
                        opencv_imgproc.FONT_HERSHEY_SIMPLEX, 0.75, new Scalar(0, 0, 255, 255), 2, 0, false);
            }

            opencv_highgui.imshow("Tracking del Cohete", frame);
            if (opencv_highgui.waitKey(25) == 'q') {
                break;
            }
        }

        cap.release();
        opencv_highgui.destroyAllWindows();

        // 4. Resultado final
        if (!posicionesY.isEmpty()) {
            double yMinimaPx = Collections.min(posicionesY);
            double distanciaPx = yInicialPx - yMinimaPx;
            double alturaMaxima = distanciaPx * metrosPorPixel;

            System.out.println("\n==================================================");
            System.out.println(" ¡CÁLCULO COMPLETADO!");
            System.out.printf(" -> Altura máxima alcanzada: %.2f metros\n", alturaMaxima);
            System.out.println("==================================================");
        } else {
            System.out.println("\n No se pudo registrar la trayectoria del cohete.");
        }
    }
}
